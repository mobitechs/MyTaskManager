<?php
require_once 'BaseDAO.php';
require_once '../model/NewRegistrationEmails.php';
require_once '../model/SendSMS.php';
require_once '../model/UsersDetailsEmails.php';

class UsersDetailsDAO
{

    private $con;
    private $msg;
    private $data;

    // Attempts to initialize the database connection using the supplied info.
    public function __construct()
    {
        $baseDAO = new BaseDAO();
        $this->con = $baseDAO->getConnection();
        mysqli_set_charset($this->con, 'utf8'); //for hindi content
    }
	
	public function userRegister($name,$email,$phone,$password)
    {
        try {
			
              $sql = "SELECT * FROM users WHERE email='" . $email."' OR phone = '" . $phone."'";      
            
			$isValidating = mysqli_query($this->con, $sql);			
            $count = mysqli_num_rows($isValidating);
            if ($count != 0) {
                $this->data = "User already exist";			
            } 
			else {
                $sql = "INSERT INTO users(name,email,phone,password)
								VALUES (									
									'".$name."',									
									'".$email."',									
									'".$phone."',												
									'".$password."'
								)";

                $isInserted = mysqli_query($this->con, $sql);		
				//print_r($sql);
                
                if ($isInserted) {                 
					$this->data = "USER_DETAILS_SAVED";
					$numOfRows = mysqli_insert_id($this->con);
					 $sql = "SELECT * FROM users WHERE email='" . $email."' OR phone = '" . $phone."' AND password='" . $password. "'";      
						$isValidating = mysqli_query($this->con, $sql);			
						$count = mysqli_num_rows($isValidating);				
												  				
						$sendNewRegistrationemailIds = new NewRegistrationEmails();
						$this->data = $sendNewRegistrationemailIds -> SendNewUserRegistrationEmail($userName,$emailId,$mobileNo,$numOfRows);					
				
						if ($count != 0) {
							$this->data = array();
							while ($rowdata = mysqli_fetch_assoc($isValidating)) {
								$this->data[] = $rowdata;                    
							}
						}
                } else {
                    $this->data = "Registration failed";
                }
                
            }
        } catch (Exception $e) {
            echo 'SQL Exception: ' . $e->getMessage();
        }
        return $this->data;
    }
  
    public function userLogin($userLoginId, $password)
    {
        try {
             $sql = "SELECT * FROM  users 
					WHERE (email='" . $userLoginId."' OR phone = '" . $userLoginId."') AND password='" . $password. "'";
           // print_r($sql);
			$isValidating = mysqli_query($this->con, $sql);			
            $count = mysqli_num_rows($isValidating);
            if ($count != 0) {
                $this->data = "SUCCESS_LOGIN";
				$this->data = array();
                while ($rowdata = mysqli_fetch_assoc($isValidating)) {
                    $this->data[] = $rowdata;                    
                }
            } 
			else {
				$this->data = "Login Failed";
            }
        } catch (Exception $e) {
            echo 'SQL Exception: ' . $e->getMessage();
        }
        return $this->data;
    }

    public function forgotPassword($email)
    {
        try {
            $this->con->options(MYSQLI_OPT_CONNECT_TIMEOUT, 500);
           
            $sql = "SELECT * FROM users WHERE email='".$email."'";
			//print_r($sql);
            $isValidating = mysqli_query($this->con, $sql);
            $count = mysqli_num_rows($isValidating);
            if ($count == 1) {
                $this->data = "VALID_EMAIL";
                $resetPassword = new UsersDetailsEmails();
                $this->data = $resetPassword ->GenarateOTPForForgoPassword($email);
                
			}
			else {
                $this->data = "email not found";
            }

        } catch (Exception $e) {
            echo 'SQL Exception: ' . $e->getMessage();
        }
        return $this->data;
    }

 

	public function SavingOTPToUserDetails($genaratedRandomNo,$email)
    {
        try {
            // print_r($email);

            $sql = "UPDATE users SET otp='".$genaratedRandomNo."' WHERE email='".$email."'";
            $isUpdate = mysqli_query($this->con, $sql);
            if ($isUpdate) {
                //$count = mysqli_affected_rows($this->con);
                //if ($count==1) {
                $this->data = "RANDOM_NO_SUCCESSFULLY_UPDATED";
            } else {
                $this->data = "RANDOM_NO_NOT_UPDATED";
            }
        } catch (Exception $e) {
            echo 'SQL Exception: ' . $e->getMessage();
        }
        return $this->data;

	}
	public function setPassword($email, $otp, $password)
    {
        try {
            $sql = "UPDATE users SET password='".$password."' WHERE email='".$email."' AND otp='".$otp."'";
			// print_r($sql);
            //$isUpdate = mysqli_query($this->con, $sql);
            mysqli_query($this->con, $sql);
            if (mysqli_affected_rows($this->con) >= 1) {
                $this->data = "Password Set Successfully";
            } else {
                $this->data = "Enter Valid OTP";
            }
        } catch (Exception $e) {
            echo 'SQL Exception: '.$e->getMessage();
        }
        return $this->data;
    }

    public function getOTPOnEmail($email)
    {
        try {
            $this->con->options(MYSQLI_OPT_CONNECT_TIMEOUT, 500);
           
			$sql = "SELECT * FROM users WHERE email='".$email."'";
            $isValidating = mysqli_query($this->con, $sql);
            $count = mysqli_num_rows($isValidating);
            if ($count == 1) {
				$this->data = "VALID_EMAIL";
                $resetPassword = new UsersDetailsEmails();
                $this->data=$resetPassword -> GenarateOTPForForgoPassword($email);
				
            } else {
                $this->data = "Invalid Email";
            }

        } catch (Exception $e) {
            echo 'SQL Exception: ' . $e->getMessage();
        }
        return $this->data;
    }
    
	public function getUserDetails($userId)
    {
        try {
            $this->con->options(MYSQLI_OPT_CONNECT_TIMEOUT, 500);

            $sql = "SELECT * FROM users WHERE userId='".$userId."'";
            $isValidating = mysqli_query($this->con, $sql);		
            $count = mysqli_num_rows($isValidating);
			//print_r($sql);		
            if ($count >= 1) {
				$this->data = array();
                while ($rowdata = mysqli_fetch_assoc($isValidating)) {
                    $this->data[] = $rowdata;                    
                }			
            } else {
                $this->data = "User details are not available";
            }
        } catch (Exception $e) {
            echo 'SQL Exception: ' . $e->getMessage();
        }
        return $this->data;
    }
	
	public function createTeam($teamName,$description,$image,$updatedBy)
    {
        try {
              $sql = "SELECT * FROM teamDetails WHERE teamName='" . $teamName."'";      
            
			$isValidating = mysqli_query($this->con, $sql);			
            $count = mysqli_num_rows($isValidating);
            if ($count != 0) {
                $this->data = "Team is already exist";			
            } 
			else {
                $sql = "INSERT INTO teamDetails(teamName,description,image,updatedBy)
								VALUES (									
									'".$teamName."',									
									'".$description."',									
									'".$image."',												
									'".$updatedBy."'
								)";

                $isInserted = mysqli_query($this->con, $sql);		
				//print_r($sql);
                if ($isInserted) {                 						  									
					 $this->data = "Team creation Successfully";
                } else {
                    $this->data = "Team creation failed";
                }
            }
        } catch (Exception $e) {
            echo 'SQL Exception: ' . $e->getMessage();
        }
        return $this->data;
    }
	
	public function editTeam($teamId,$teamName,$description,$image,$updatedBy)
    {
        try {

             $sql = "SELECT * FROM teamDetails WHERE teamName='" . $teamName."'";      
            
			$isValidating = mysqli_query($this->con, $sql);			
            $count = mysqli_num_rows($isValidating);
            if ($count != 0) {
                $this->data = "Team name is already exist";			
            } 
			else {
                $sql = "UPDATE teamDetails SET 
					teamName='".$teamName."', 
					description='".$description."',
					image='".$image."',
					updatedBy='".$updatedBy."'
					WHERE teamId='".$teamId."'";
                //print_r($sql);
                //$isUpdate = mysqli_query($this->con, $sql);
                mysqli_query($this->con, $sql);
                if (mysqli_affected_rows($this->con) >= 1) {
                    $this->data = "Team Details updated Successfully";
                } else {
                    $this->data = "Failed to update team details";
                }
            }
            
        } catch (Exception $e) {
            echo 'SQL Exception: '.$e->getMessage();
        }
        return $this->data;
    }
	
	public function deleteTeam($teamId)
    {
        try {
            $sql = "DELETE FROM teamDetails
					WHERE teamId='".$teamId."'";
            mysqli_query($this->con, $sql);
            if (mysqli_affected_rows($this->con) >= 1) {
                $this->data = "Team deleted successfully";
            } else {
                $this->data = "Failed to delete team";
            }
        } catch (Exception $e) {
            echo 'SQL Exception: '.$e->getMessage();
        }
        return $this->data;
    }
	
	public function addTeamMember($teamId,$teamMemberId,$updatedBy)
    {
        try {
			
              $sql = "SELECT * FROM teamMemberDetails WHERE teamId='" . $teamId."' AND teamMemberId = '" . $teamMemberId."'";      
            
			$isValidating = mysqli_query($this->con, $sql);			
            $count = mysqli_num_rows($isValidating);
            if ($count != 0) {
                $this->data = "Member already exist";			
            } 
			else {
                $sql = "INSERT INTO teamMemberDetails(teamId,teamMemberId,updatedBy)
								VALUES (									
									'".$teamId."',									
									'".$teamMemberId."',									
									'".$updatedBy."'
								)";

                $isInserted = mysqli_query($this->con, $sql);		
				//print_r($sql);
                if ($isInserted) {					
					
					$this->data = "Member added successfully";
                } else {
                    $this->data = "Faild to add member";
                }
            }
        } catch (Exception $e) {
            echo 'SQL Exception: ' . $e->getMessage();
        }
        return $this->data;
    }
	
	public function deleteTeamMember($teamId,$teamMemberId,$updatedBy)
    {
        try {
            $sql = "DELETE FROM teamMemberDetails
					WHERE teamId='".$teamId."' AND teamMemberId='".$teamMemberId."'";
            mysqli_query($this->con, $sql);
            if (mysqli_affected_rows($this->con) >= 1) {
                $this->data = "Team member deleted successfully";
            } else {
                $this->data = "Failed to delete team member";
            }
        } catch (Exception $e) {
            echo 'SQL Exception: '.$e->getMessage();
        }
        return $this->data;
    }
    
	
	public function addTask($taskName,$taskDescription,$kpi,$ownerId,$assigneeId,$teamId,$expectedDate,$status,$updatedBy)
    {
        try {
			$sql = "INSERT INTO taskDetails(taskName,taskDescription,kpi,ownerId,assigneeId,teamId,expectedDate,status,updatedBy)
					VALUES (									
						'".$taskName."',									
						'".$taskDescription."',									
						'".$kpi."',									
						'".$ownerId."',									
						'".$assigneeId."',									
						'".$teamId."',									
						'".$expectedDate."',									
						'".$status."',									
						'".$updatedBy."'
					)";

                $isInserted = mysqli_query($this->con, $sql);		
				//print_r($sql);
                if ($isInserted) {										
					$this->data = "Task added successfully";
                } else {
                    $this->data = "Faild to add task";
                }
        } catch (Exception $e) {
            echo 'SQL Exception: ' . $e->getMessage();
        }
        return $this->data;
    }

	public function editTask($taskId,$taskName,$taskDescription,$kpi,$ownerId,$assigneeId,$teamId,$expectedDate,$status,$updatedBy)
    {
        try {
            $sql = "UPDATE taskDetails 
					SET 
						taskName = '".$taskName."', 
						taskDescription = '".$taskDescription."', 
						kpi = '".$kpi."', 
						ownerId = '".$ownerId."', 
						assigneeId = '".$assigneeId."', 
						teamId = '".$teamId."', 
						expectedDate = '".$expectedDate."', 
						status = '".$status."', 
						updatedBy = '".$updatedBy."' 
					WHERE taskId = '".$taskId."'";
			//print_r($sql);
            //$isUpdate = mysqli_query($this->con, $sql);
            mysqli_query($this->con, $sql);
            if (mysqli_affected_rows($this->con) >= 1) {
                $this->data = "Task Details updated Successfully";
            } else {
                $this->data = "Failed to update task details";
            }
        } catch (Exception $e) {
            echo 'SQL Exception: '.$e->getMessage();
        }
        return $this->data;
    }

	public function deleteTask($taskId,$updatedBy)
    {
        try {
            $sql = "DELETE FROM taskDetails
					WHERE taskId='".$taskId."'";
            mysqli_query($this->con, $sql);
            if (mysqli_affected_rows($this->con) >= 1) {
                $this->data = "Task deleted successfully";
            } else {
                $this->data = "Failed to delete task";
            }
        } catch (Exception $e) {
            echo 'SQL Exception: '.$e->getMessage();
        }
        return $this->data;
    }
	
	public function updateStatus($taskId,$status,$updatedBy)
    {
        try {
            $sql = "UPDATE taskDetails 
					SET 						
						status = '".$status."', 
						updatedBy = '".$updatedBy."' 
					WHERE taskId = '".$taskId."'";
			//print_r($sql);
            //$isUpdate = mysqli_query($this->con, $sql);
            mysqli_query($this->con, $sql);
            if (mysqli_affected_rows($this->con) >= 1) {
                $this->data = "Task Details updated Successfully";
            } else {
                $this->data = "Failed to update task details";
            }
        } catch (Exception $e) {
            echo 'SQL Exception: '.$e->getMessage();
        }
        return $this->data;
    }
	
	public function addReminderForTask($taskId,$noOfReminder,$updatedBy)
    {
        try {
            $sql = "UPDATE taskDetails 
					SET 						
						noOfReminder = '".$noOfReminder."', 
						updatedBy = '".$updatedBy."' 
					WHERE taskId = '".$taskId."'";
			//print_r($sql);
            //$isUpdate = mysqli_query($this->con, $sql);
            mysqli_query($this->con, $sql);
            if (mysqli_affected_rows($this->con) >= 1) {
                $this->data = "Task Details updated Successfully";
            } else {
                $this->data = "Failed to update task details";
            }
        } catch (Exception $e) {
            echo 'SQL Exception: '.$e->getMessage();
        }
        return $this->data;
    }
	
	public function addComment($taskId,$comment,$expectedDate,$updatedBy)
    {
        try {
            $sql = "UPDATE taskDetails 
					SET 						
						comment = '".$comment."', 
						expectedDate = '".$expectedDate."', 
						updatedBy = '".$updatedBy."' 
					WHERE taskId = '".$taskId."'";
			//print_r($sql);
            //$isUpdate = mysqli_query($this->con, $sql);
            mysqli_query($this->con, $sql);
            if (mysqli_affected_rows($this->con) >= 1) {
                $this->data = "Comment added successfully";
            } else {
                $this->data = "Failed to update comment";
            }
        } catch (Exception $e) {
            echo 'SQL Exception: '.$e->getMessage();
        }
        return $this->data;
    }
	
	public function editComment($taskId,$comment,$dueDate,$updatedBy)
    {
        try {
            $sql = "UPDATE taskDetails 
					SET 						
						comment = '".$comment."', 
						expectedDate = '".$expectedDate."', 
						updatedBy = '".$updatedBy."' 
					WHERE taskId = '".$taskId."'";
			//print_r($sql);
            //$isUpdate = mysqli_query($this->con, $sql);
            mysqli_query($this->con, $sql);
            if (mysqli_affected_rows($this->con) >= 1) {
                $this->data = "Comment updated Successfully";
            } else {
                $this->data = "Failed to update comment";
            }
        } catch (Exception $e) {
            echo 'SQL Exception: '.$e->getMessage();
        }
        return $this->data;
    }
	
	
	public function getTaskListAssignedByMe($userId)
    {
        try {
            $this->con->options(MYSQLI_OPT_CONNECT_TIMEOUT, 500);

            $sql = "SELECT * FROM task WHERE taskAssignerId='".$userId."'";
            $isValidating = mysqli_query($this->con, $sql);		
            $count = mysqli_num_rows($isValidating);
			//print_r($sql);		
            if ($count >= 1) {
				$this->data = array();
                while ($rowdata = mysqli_fetch_assoc($isValidating)) {
                    $this->data[] = $rowdata;                    
                }			
            } else {
                $this->data = "Task not available";
            }
        } catch (Exception $e) {
            echo 'SQL Exception: ' . $e->getMessage();
        }
        return $this->data;
    }
	
	
	public function getTaskListAssignedToMe($userId)
    {
        try {
            $this->con->options(MYSQLI_OPT_CONNECT_TIMEOUT, 500);

            $sql = "SELECT * FROM users WHERE assigneeId='".$userId."'";
            $isValidating = mysqli_query($this->con, $sql);		
            $count = mysqli_num_rows($isValidating);
			//print_r($sql);		
            if ($count >= 1) {
				$this->data = array();
                while ($rowdata = mysqli_fetch_assoc($isValidating)) {
                    $this->data[] = $rowdata;                    
                }			
            } else {
                $this->data = "Task not available";
            }
        } catch (Exception $e) {
            echo 'SQL Exception: ' . $e->getMessage();
        }
        return $this->data;
    }
    
}

?>
